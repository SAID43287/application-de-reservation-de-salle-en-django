from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import Utilisateur

class InscriptionForm(UserCreationForm):
    first_name = forms.CharField(label='Prénom', max_length=100,
        widget=forms.TextInput(attrs={'placeholder':'Jean'}))
    last_name = forms.CharField(label='Nom', max_length=100,
        widget=forms.TextInput(attrs={'placeholder':'Dupont'}))
    email = forms.EmailField(label='Email',
        widget=forms.EmailInput(attrs={'placeholder':'jean@example.com'}))
    telephone = forms.CharField(label='Téléphone', max_length=20, required=False,
        widget=forms.TextInput(attrs={'placeholder':'+212 6 00 00 00 00'}))
    service = forms.CharField(label='Service / Département', max_length=100, required=False,
        widget=forms.TextInput(attrs={'placeholder':'Ex : RH, Informatique…'}))

    class Meta:
        model = Utilisateur
        fields = ['first_name','last_name','email','telephone','service','password1','password2']

    def save(self, commit=True):
        u = super().save(commit=False)
        u.username = self.cleaned_data['email']
        u.telephone = self.cleaned_data.get('telephone','')
        u.service = self.cleaned_data.get('service','')
        if commit: u.save()
        return u

class ConnexionForm(AuthenticationForm):
    username = forms.EmailField(label='Email',
        widget=forms.EmailInput(attrs={'placeholder':'votre@email.com','autofocus':True}))
    password = forms.CharField(label='Mot de passe',
        widget=forms.PasswordInput(attrs={'placeholder':'••••••••'}))

class ProfilForm(forms.ModelForm):
    class Meta:
        model = Utilisateur
        fields = ['first_name','last_name','email','telephone','service']
        labels = {'first_name':'Prénom','last_name':'Nom','email':'Email',
                  'telephone':'Téléphone','service':'Service'}
