from django.contrib.auth.models import AbstractUser
from django.db import models

class Utilisateur(AbstractUser):
    role = models.CharField(max_length=20, default='user',
                            choices=[('user','Utilisateur'),('admin','Administrateur')])
    telephone = models.CharField(max_length=20, blank=True)
    service = models.CharField(max_length=100, blank=True)

    class Meta:
        verbose_name = 'Utilisateur'

    @property
    def is_admin_role(self):
        return self.role == 'admin' or self.is_staff

    @property
    def nom_complet(self):
        return f"{self.first_name} {self.last_name}".strip() or self.username

    def __str__(self):
        return self.email or self.username
