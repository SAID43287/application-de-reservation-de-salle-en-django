from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib import messages
from .forms import InscriptionForm, ConnexionForm, ProfilForm

def inscription(request):
    if request.user.is_authenticated:
        return redirect('index')
    if request.method == 'POST':
        form = InscriptionForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f"Bienvenue {user.first_name} !")
            return redirect('index')
    else:
        form = InscriptionForm()
    return render(request, 'comptes/inscription.html', {'form': form})

def connexion(request):
    if request.user.is_authenticated:
        return redirect('index')
    if request.method == 'POST':
        form = ConnexionForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f"Bon retour, {user.first_name} !")
            return redirect(request.GET.get('next', 'index'))
        else:
            messages.error(request, "Email ou mot de passe incorrect.")
    else:
        form = ConnexionForm()
    return render(request, 'comptes/connexion.html', {'form': form})

def deconnexion(request):
    if request.user.is_authenticated:
        messages.success(request, f"À bientôt, {request.user.first_name} !")
        logout(request)
    return redirect('index')

@login_required
def profil(request):
    from salles.models import Reservation
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'profil':
            form = ProfilForm(request.POST, instance=request.user)
            if form.is_valid():
                form.save()
                messages.success(request, "Profil mis à jour.")
                return redirect('profil')
        elif action == 'password':
            pwd_form = PasswordChangeForm(request.user, request.POST)
            if pwd_form.is_valid():
                pwd_form.save()
                update_session_auth_hash(request, pwd_form.user)
                messages.success(request, "Mot de passe modifié.")
                return redirect('profil')
            else:
                for errs in pwd_form.errors.values():
                    for e in errs:
                        messages.error(request, e)
                return redirect('profil')
    form = ProfilForm(instance=request.user)
    reservations = Reservation.objects.filter(utilisateur=request.user).select_related('salle')[:5]
    return render(request, 'comptes/profil.html', {'form': form, 'reservations': reservations})
