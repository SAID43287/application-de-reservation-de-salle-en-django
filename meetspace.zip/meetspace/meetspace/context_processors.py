import django

def django_version(request):
    return {'django_version': django.__version__}
