from django.contrib import admin as django_admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from comptes import views as cv
from salles import views as sv

urlpatterns = [
    path('django-admin/', django_admin.site.urls),
    path('inscription/', cv.inscription, name='inscription'),
    path('connexion/', cv.connexion, name='connexion'),
    path('deconnexion/', cv.deconnexion, name='deconnexion'),
    path('profil/', cv.profil, name='profil'),
    path('', sv.index, name='index'),
    path('salles/', sv.liste_salles, name='liste_salles'),
    path('salle/<int:pk>/', sv.detail_salle, name='detail_salle'),
    path('api/disponibilite/<int:pk>/', sv.api_disponibilite, name='api_disponibilite'),
    path('reserver/<int:pk>/', sv.reserver, name='reserver'),
    path('confirmation/<int:pk>/', sv.confirmation, name='confirmation'),
    path('mes-reservations/', sv.mes_reservations, name='mes_reservations'),
    path('annuler/<int:pk>/', sv.annuler_reservation, name='annuler_reservation'),
    path('admin/', sv.admin_dashboard, name='admin_dashboard'),
    path('admin/salle/ajouter/', sv.admin_ajouter_salle, name='admin_ajouter_salle'),
    path('admin/salle/<int:pk>/modifier/', sv.admin_modifier_salle, name='admin_modifier_salle'),
    path('admin/salle/<int:pk>/supprimer/', sv.admin_supprimer_salle, name='admin_supprimer_salle'),
    path('admin/type/ajouter/', sv.admin_ajouter_type, name='admin_ajouter_type'),
    path('admin/type/<int:pk>/supprimer/', sv.admin_supprimer_type, name='admin_supprimer_type'),
    path('admin/user/<int:pk>/toggle/', sv.admin_toggle_user, name='admin_toggle_user'),
    path('admin/user/<int:pk>/role/', sv.admin_toggle_role, name='admin_toggle_role'),
    path('admin/user/<int:pk>/supprimer/', sv.admin_supprimer_user, name='admin_supprimer_user'),
    path('admin/reservation/<int:pk>/annuler/', sv.admin_annuler_reservation, name='admin_annuler_reservation'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
