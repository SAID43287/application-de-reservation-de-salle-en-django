from django.contrib import admin
from .models import TypeSalle, Salle, Reservation

@admin.register(TypeSalle)
class TypeSalleAdmin(admin.ModelAdmin):
    list_display = ['nom','description']

@admin.register(Salle)
class SalleAdmin(admin.ModelAdmin):
    list_display = ['nom','type_salle','capacite','etage','active']
    list_filter = ['type_salle','active']

@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ['salle','utilisateur','date_reservation','heure_debut','heure_fin','statut']
    list_filter = ['statut']
