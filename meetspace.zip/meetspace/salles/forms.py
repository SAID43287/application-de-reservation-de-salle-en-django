from django import forms
from datetime import date
from .models import Salle, TypeSalle, Reservation

EQUIPS = ['Projecteur HD', 'Écran LED', 'Tableau blanc', 'Visioconférence', 'Système audio', 'WiFi dédié', 'Climatisation', 'Imprimante', 'Minibar', 'Insonorisation', 'Post-it géants', 'Cafetière', 'Téléphone', 'Paperboard']
HEURES = [(f'{h:02d}:{m:02d}',f'{h:02d}:{m:02d}') for h in range(7,21) for m in (0,30)]

class SalleForm(forms.ModelForm):
    equipements_coches = forms.MultipleChoiceField(
        choices=[(e,e) for e in EQUIPS], widget=forms.CheckboxSelectMultiple,
        required=False, label='Équipements')
    equipements_custom = forms.CharField(required=False, label='Équipements personnalisés (virgules)',
        widget=forms.TextInput(attrs={'placeholder':'Ex : Tableau numérique, HDMI…'}))

    class Meta:
        model = Salle
        fields = ['nom','type_salle','capacite','description','etage','superficie',
                  'image','image_url','image_color','active']
        labels = {'nom':'Nom','type_salle':'Type','capacite':'Capacité',
                   'description':'Description','etage':'Étage','superficie':'Superficie (m²)',
                   'image':'Photo (fichier)','image_url':'URL image externe',
                   'image_color':'Couleur','active':'Salle active (visible)'}
        widgets = {'description':forms.Textarea(attrs={'rows':3}),
                    'etage':forms.TextInput(attrs={'placeholder':'3ème étage'}),
                    'image_url':forms.URLInput(attrs={'placeholder':'https://images.unsplash.com/…'})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            eq = self.instance.equipements or []
            self.fields['equipements_coches'].initial = [e for e in eq if e in EQUIPS]
            self.fields['equipements_custom'].initial = ', '.join(e for e in eq if e not in EQUIPS)

    def save(self, commit=True):
        s = super().save(commit=False)
        coches = self.cleaned_data.get('equipements_coches',[])
        custom = [e.strip() for e in self.cleaned_data.get('equipements_custom','').split(',') if e.strip()]
        s.equipements = list(coches) + custom
        if commit: s.save()
        return s

class TypeSalleForm(forms.ModelForm):
    class Meta:
        model = TypeSalle
        fields = ['nom','description']
        labels = {'nom':'Nom du type','description':'Description'}
        widgets = {'nom':forms.TextInput(attrs={'placeholder':'Ex : Salle de formation'})}

class ReservationForm(forms.ModelForm):
    heure_debut = forms.ChoiceField(choices=HEURES, label='Heure de début')
    heure_fin = forms.ChoiceField(choices=HEURES, label='Heure de fin')

    class Meta:
        model = Reservation
        fields = ['date_reservation','heure_debut','heure_fin','motif','nb_participants']
        labels = {'date_reservation':'Date','motif':'Motif','nb_participants':'Participants'}
        widgets = {'date_reservation':forms.DateInput(attrs={'type':'date'})}

    def __init__(self, *args, salle=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.salle = salle
        self.fields['date_reservation'].widget.attrs['min'] = str(date.today())
        if salle:
            self.fields['nb_participants'].widget.attrs['max'] = salle.capacite
        if not self.data and not self.instance.pk:
            self.fields['heure_fin'].initial = '08:00'

    def clean(self):
        cd = super().clean()
        d, hd, hf, nb = cd.get('date_reservation'), cd.get('heure_debut'), cd.get('heure_fin'), cd.get('nb_participants')
        if d and d < date.today():
            raise forms.ValidationError("La date ne peut pas être dans le passé.")
        if hd and hf and hd >= hf:
            raise forms.ValidationError("L'heure de fin doit être après l'heure de début.")
        if nb and self.salle and nb > self.salle.capacite:
            raise forms.ValidationError(f"Capacité max : {self.salle.capacite} personnes.")
        if d and hd and hf and self.salle:
            from datetime import datetime
            hd_t = datetime.strptime(hd,'%H:%M').time()
            hf_t = datetime.strptime(hf,'%H:%M').time()
            if not self.salle.is_available(d, hd_t, hf_t):
                raise forms.ValidationError("Ce créneau est déjà réservé pour cette salle.")
        return cd
