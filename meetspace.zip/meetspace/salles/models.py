import secrets
from django.db import models
from django.conf import settings

def upload_path(instance, filename):
    ext = filename.rsplit('.', 1)[-1].lower()
    return f'salles/{secrets.token_hex(8)}.{ext}'

class TypeSalle(models.Model):
    nom = models.CharField(max_length=100, unique=True)
    description = models.CharField(max_length=200, blank=True)
    class Meta:
        verbose_name = 'Type de salle'
        ordering = ['nom']
    def __str__(self): return self.nom

class Salle(models.Model):
    nom = models.CharField(max_length=100)
    type_salle = models.ForeignKey(TypeSalle, on_delete=models.SET_NULL,
                                   null=True, blank=True, related_name='salles')
    capacite = models.PositiveIntegerField()
    description = models.TextField(blank=True)
    etage = models.CharField(max_length=50, blank=True)
    superficie = models.PositiveIntegerField(default=0)
    equipements = models.JSONField(default=list, blank=True)
    image = models.ImageField(upload_to=upload_path, blank=True, null=True)
    image_url = models.URLField(blank=True)
    image_color = models.CharField(max_length=20, default='#1a6b8a')
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Salle'
        ordering = ['nom']

    def __str__(self): return self.nom

    def get_image_url(self):
        if self.image:
            try: return self.image.url
            except: pass
        if self.image_url: return self.image_url
        return 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=700&q=80'

    def is_available(self, date, hd, hf):
        return not self.reservations.filter(
            date_reservation=date, statut='confirmee',
            heure_debut__lt=hf, heure_fin__gt=hd
        ).exists()

class Reservation(models.Model):
    STATUTS = [('confirmee','Confirmée'),('annulee','Annulée')]
    salle = models.ForeignKey(Salle, on_delete=models.CASCADE, related_name='reservations')
    utilisateur = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reservations')
    date_reservation = models.DateField()
    heure_debut = models.TimeField()
    heure_fin = models.TimeField()
    motif = models.CharField(max_length=200, blank=True)
    nb_participants = models.PositiveIntegerField(default=1)
    statut = models.CharField(max_length=20, choices=STATUTS, default='confirmee')
    date_creation = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Réservation'
        ordering = ['-date_reservation', '-heure_debut']

    def __str__(self):
        return f"{self.salle.nom} — {self.date_reservation} {self.heure_debut}"

    @property
    def est_future(self):
        from datetime import date
        return self.date_reservation >= date.today()
