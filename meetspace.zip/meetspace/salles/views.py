from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from datetime import date, datetime
from functools import wraps
from .models import Salle, TypeSalle, Reservation
from .forms import SalleForm, TypeSalleForm, ReservationForm
from comptes.models import Utilisateur

def admin_required(f):
    @wraps(f)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect(f'/connexion/?next={request.path}')
        if not request.user.is_admin_role:
            messages.error(request, "Accès réservé aux administrateurs.")
            return redirect('index')
        return f(request, *args, **kwargs)
    return wrapper

# ── Public ──────────────────────────────────────────────────────
def index(request):
    salles = Salle.objects.filter(active=True).select_related('type_salle')
    today = date.today()
    return render(request, 'salles/index.html', {
        'salles': salles[:4],
        'total_salles': salles.count(),
        'reservations_today': Reservation.objects.filter(date_reservation=today, statut='confirmee').count(),
        'total_reservations': Reservation.objects.filter(statut='confirmee').count(),
        'total_users': Utilisateur.objects.count(),
    })

def liste_salles(request):
    types = TypeSalle.objects.all()
    qs = Salle.objects.filter(active=True).select_related('type_salle')
    filtre = request.GET.get('type', '')
    if filtre:
        qs = qs.filter(type_salle_id=filtre)
    return render(request, 'salles/liste.html', {'salles': qs, 'types': types, 'filtre': filtre})

def detail_salle(request, pk):
    salle = get_object_or_404(Salle, pk=pk)
    today = date.today()
    reservations = salle.reservations.filter(
        date_reservation__gte=today, statut='confirmee'
    ).select_related('utilisateur').order_by('date_reservation', 'heure_debut')
    return render(request, 'salles/detail.html', {'salle': salle, 'reservations': reservations, 'today': today})

def api_disponibilite(request, pk):
    salle = get_object_or_404(Salle, pk=pk)
    try:
        d = datetime.strptime(request.GET.get('date', ''), '%Y-%m-%d').date()
    except:
        return JsonResponse({'error': 'Date invalide'}, status=400)
    rs = salle.reservations.filter(date_reservation=d, statut='confirmee')
    return JsonResponse({
        'creneaux_occupes': [{'debut': r.heure_debut.strftime('%H:%M'), 'fin': r.heure_fin.strftime('%H:%M')} for r in rs]
    })

# ── Réservations ────────────────────────────────────────────────
@login_required
def reserver(request, pk):
    salle = get_object_or_404(Salle, pk=pk, active=True)
    if request.method == 'POST':
        form = ReservationForm(request.POST, salle=salle)
        if form.is_valid():
            r = form.save(commit=False)
            r.salle = salle
            r.utilisateur = request.user
            r.heure_debut = datetime.strptime(form.cleaned_data['heure_debut'], '%H:%M').time()
            r.heure_fin = datetime.strptime(form.cleaned_data['heure_fin'], '%H:%M').time()
            r.save()
            messages.success(request, f"Réservation #{r.pk} confirmée !")
            return redirect('confirmation', pk=r.pk)
        else:
            for errs in form.errors.values():
                for e in errs:
                    messages.error(request, e)
    else:
        form = ReservationForm(salle=salle)
    return render(request, 'salles/reserver.html', {'salle': salle, 'form': form, 'today': str(date.today())})

@login_required
def confirmation(request, pk):
    r = get_object_or_404(Reservation, pk=pk)
    if r.utilisateur != request.user and not request.user.is_admin_role:
        messages.error(request, "Accès non autorisé.")
        return redirect('index')
    return render(request, 'salles/confirmation.html', {'reservation': r})

@login_required
def mes_reservations(request):
    today = date.today()
    reservations = Reservation.objects.filter(utilisateur=request.user).select_related('salle').order_by('-date_reservation')
    return render(request, 'salles/mes_reservations.html', {'reservations': reservations, 'today': today})

@login_required
def annuler_reservation(request, pk):
    r = get_object_or_404(Reservation, pk=pk)
    if r.utilisateur != request.user and not request.user.is_admin_role:
        messages.error(request, "Non autorisé.")
        return redirect('mes_reservations')
    if request.method == 'POST':
        if r.date_reservation >= date.today():
            r.statut = 'annulee'; r.save()
            messages.success(request, "Réservation annulée.")
        else:
            messages.error(request, "Impossible d'annuler une réservation passée.")
    return redirect('mes_reservations')

# ── Admin ────────────────────────────────────────────────────────
@admin_required
def admin_dashboard(request):
    return render(request, 'admin_custom/dashboard.html', {
        'salles': Salle.objects.select_related('type_salle').all(),
        'types': TypeSalle.objects.all(),
        'users': Utilisateur.objects.order_by('-date_joined'),
        'reservations': Reservation.objects.select_related('salle', 'utilisateur').order_by('-date_reservation')[:100],
        'today': date.today(),
    })

@admin_required
def admin_ajouter_salle(request):
    if request.method == 'POST':
        form = SalleForm(request.POST, request.FILES)
        if form.is_valid():
            salle = form.save()
            messages.success(request, f'Salle "{salle.nom}" créée.')
            return redirect('admin_dashboard')
    else:
        form = SalleForm()
    return render(request, 'admin_custom/salle_form.html', {'form': form, 'titre': 'Nouvelle salle', 'action': 'Créer'})

@admin_required
def admin_modifier_salle(request, pk):
    salle = get_object_or_404(Salle, pk=pk)
    if request.method == 'POST':
        if request.POST.get('supprimer_image') and salle.image:
            import os
            try:
                if os.path.exists(salle.image.path): os.remove(salle.image.path)
            except: pass
            salle.image = None; salle.save()
        form = SalleForm(request.POST, request.FILES, instance=salle)
        if form.is_valid():
            salle = form.save()
            messages.success(request, f'Salle "{salle.nom}" mise à jour.')
            return redirect('admin_dashboard')
    else:
        form = SalleForm(instance=salle)
    return render(request, 'admin_custom/salle_form.html', {'form': form, 'salle': salle, 'titre': f'Modifier {salle.nom}', 'action': 'Enregistrer'})

@admin_required
def admin_supprimer_salle(request, pk):
    s = get_object_or_404(Salle, pk=pk)
    if request.method == 'POST':
        nom = s.nom
        if s.image:
            import os
            try:
                if os.path.exists(s.image.path): os.remove(s.image.path)
            except: pass
        s.delete()
        messages.success(request, f'Salle "{nom}" supprimée.')
    return redirect('admin_dashboard')

@admin_required
def admin_ajouter_type(request):
    if request.method == 'POST':
        form = TypeSalleForm(request.POST)
        if form.is_valid():
            t = form.save()
            messages.success(request, f'Type "{t.nom}" créé.')
        else:
            for errs in form.errors.values():
                for e in errs: messages.error(request, e)
    return redirect('admin_dashboard')

@admin_required
def admin_supprimer_type(request, pk):
    t = get_object_or_404(TypeSalle, pk=pk)
    if request.method == 'POST':
        if t.salles.exists():
            messages.error(request, f'{t.salles.count()} salle(s) utilisent ce type.')
        else:
            nom = t.nom; t.delete()
            messages.success(request, f'Type "{nom}" supprimé.')
    return redirect('admin_dashboard')

@admin_required
def admin_toggle_user(request, pk):
    u = get_object_or_404(Utilisateur, pk=pk)
    if request.method == 'POST':
        if u == request.user:
            messages.error(request, "Impossible de modifier votre propre compte.")
        else:
            u.is_active = not u.is_active; u.save()
            messages.success(request, f'Compte {"activé" if u.is_active else "désactivé"}.')
    return redirect('admin_dashboard')

@admin_required
def admin_toggle_role(request, pk):
    u = get_object_or_404(Utilisateur, pk=pk)
    if request.method == 'POST':
        if u == request.user:
            messages.error(request, "Impossible de modifier votre propre rôle.")
        else:
            u.role = 'user' if u.role == 'admin' else 'admin'; u.save()
            messages.success(request, f'Rôle → {u.role}.')
    return redirect('admin_dashboard')

@admin_required
def admin_supprimer_user(request, pk):
    u = get_object_or_404(Utilisateur, pk=pk)
    if request.method == 'POST':
        if u == request.user:
            messages.error(request, "Impossible de supprimer votre propre compte.")
        else:
            nom = u.nom_complet; u.delete()
            messages.success(request, f'Utilisateur "{nom}" supprimé.')
    return redirect('admin_dashboard')

@admin_required
def admin_annuler_reservation(request, pk):
    r = get_object_or_404(Reservation, pk=pk)
    if request.method == 'POST':
        r.statut = 'annulee'; r.save()
        messages.success(request, f'Réservation #{pk} annulée.')
    return redirect('admin_dashboard')
